#include <Wire.h> 
#include <LiquidCrystal_I2C.h> // Incluimos la librería I2C para la pantalla LCD
#include <Keypad.h>            // Incluir librería para teclado matricial
#include <EEPROM.h>
#include <Servo.h>             // Añadimos la librería para el servomotor

// Tamaño (#columnas, #filas) de la pantalla LCD
LiquidCrystal_I2C lcd(0x27, 16, 2); 

char contrasena[] = "1234";   // Contraseña de 4 dígitos para usuario root
char codigo[4];               // Arreglo donde almacenaremos la contraseña digitada

int digito = 0;               // Variable que nos dirá en qué dígito vamos
int intentos = 3;             // Máximo de intentos permitidos
int tmp_intentos = 0;         // Variable temporal de intentos
boolean contrasena_correcta = false;          

const int pinBuzzer = 13;
const int ledVerde = 12;      // Pin del LED verde
const int ledRojo = 11;       // Pin del LED rojo

// --- CONFIGURACIÓN DEL SERVOMOTOR ---
Servo miServo;                // Crear el objeto Servo
const int pinServo = 8;       // Asignamos el Pin 8 para el control del servo

// --- CONFIGURACIÓN DE MATRIZ 4X4 ---
const byte filas = 4;         // Número de filas del teclado
const byte columnas = 4;      // Número de columnas del teclado

char teclas[filas][columnas] = 
{
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

// Pines asignados para evitar conflictos con pines 0, 1 (Serial) y A4, A5 (I2C)
byte pinsFilas[filas] = {10, 9, 6, 5};        
byte pinsColumnas[columnas] = {4, 3, 2, 7};    

Keypad teclado = Keypad(makeKeymap(teclas), pinsFilas, pinsColumnas, filas, columnas); 

void setup()
{
  lcd.init();                       // Inicializar la pantalla LCD
  lcd.backlight();                  // Encender la luz de fondo
  
  pinMode(pinBuzzer, OUTPUT);
  pinMode(ledVerde, OUTPUT);        // Configurar pin del LED verde como salida
  pinMode(ledRojo, OUTPUT);         // Configurar pin del LED rojo como salida
  
  // Inicialización del servo
  miServo.attach(pinServo);
  miServo.write(0);                 // Asegurar que comience en posición de cerrado (0°)
  
  tmp_intentos = intentos;          // Inicializamos los intentos temporales
  
  lcd.clear();                      
  lcd.setCursor(2, 0);              
  lcd.print("Digite Clave");        
}

void loop()        
{ 
  char tecla = teclado.getKey();    // Guardamos la tecla presionada

  // Si se presiona una tecla y no es el asterisco (*)
  if (tecla != NO_KEY && tecla != '*') 
  {      
    // Si la tecla es el numeral (#), funciona como RESET/Borrado
    if (tecla == '#') 
    {    
      digito = 0;      
      tone(pinBuzzer, 2000);        // Tono de borrado
      delay(250);
      noTone(pinBuzzer);
      
      lcd.setCursor(6, 1);          
      lcd.print("    ");
      lcd.setCursor(2, 0);          
      lcd.print("Digite Clave");        
      delay(250);       
    }
    // Evitamos que las letras A, B, C, D sean guardadas como parte de la contraseña numérica
    else if (tecla == 'A' || tecla == 'B' || tecla == 'C' || tecla == 'D')
    {
      tone(pinBuzzer, 1500); // Tono diferente para indicar tecla de función
      delay(100);
      noTone(pinBuzzer);
    }
    else // Si es un número (0-9)
    {
      tono_tecla();      
      codigo[digito] = tecla;       // Almacena el dígito ingresado         
    
      lcd.setCursor(digito + 6, 1); 
      lcd.print('*');               // Muestra un asterisco por seguridad                 
       
      digito = digito + 1;          
     
      if (digito == 4)              // Si ya se ingresaron los 4 dígitos
      {           
        verificar_contrasena();    

        if (contrasena_correcta == true)          
        { 
          tmp_intentos = intentos;          // Reiniciamos intentos
          digitalWrite(ledVerde, HIGH);     // Encender led verde        
          
          // --- ACCIÓN DEL SERVO: ABRIR ---
          miServo.write(90);                // Gira a 90 grados (Cerradura abierta)
          
          lcd.clear();        
          lcd.setCursor(3, 0);        
          lcd.print("Bienvenido");                     
          tone(pinBuzzer, 3000);
          delay(3000);                      // Esperamos 3 segundos con el acceso abierto  
          noTone(pinBuzzer);                                        
          
          // --- ACCIÓN DEL SERVO: CERRAR ---
          miServo.write(0);                 // Regresa a 0 grados (Cerradura cerrada)
          
          lcd.clear();        
          digitalWrite(ledVerde, LOW);      // Apagamos led verde
        }
        else // Si la contraseña es incorrecta
        {        
          digitalWrite(ledRojo, HIGH);      // Encendemos led rojo
          lcd.setCursor(0, 1);        
          lcd.print("Clave incorrecta"); 
          tone(pinBuzzer, 2000);            // Tono de error
          delay(500);
          noTone(pinBuzzer);
          delay(1000);        
          lcd.clear();        
          digitalWrite(ledRojo, LOW);       // Apagamos led rojo 

          if (tmp_intentos == 1) 
          {                                 // Si era el último intento
            tmp_intentos = intentos;        // Reiniciamos contador de intentos
            lcd.clear();
            lcd.setCursor(0, 0);        
            lcd.print("Acceso bloqueado"); 
            lcd.setCursor(3, 1);        
            lcd.print("Espere....");        
            delay(10000);                   // Bloqueo de 10 segundos
          } 
          else
          {
            tmp_intentos = tmp_intentos - 1; // Restamos un intento
          }        
        }
        
        // Al terminar la verificación, reseteamos variables para el próximo inicio
        digito = 0;       
        contrasena_correcta = false; 
        lcd.clear();
        lcd.setCursor(2, 0);        
        lcd.print("Digite Clave");        
        delay(250);       
      }                                     
    }       
  }       
}

void verificar_contrasena()
{ 
  if (codigo[0] == contrasena[0] && codigo[1] == contrasena[1] && codigo[2] == contrasena[2] && codigo[3] == contrasena[3]) 
  {   
    contrasena_correcta = true;
  }
  else
  {
    contrasena_correcta = false;
  } 
}

void tono_tecla()
{
  tone(pinBuzzer, 2000);            // Tono corto al presionar tecla
  delay(100);       
  noTone(pinBuzzer);  
}